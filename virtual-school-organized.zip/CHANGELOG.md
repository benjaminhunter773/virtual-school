# Changelog

## [1.0.0] - Initial Release
- Added core features and modular design.
