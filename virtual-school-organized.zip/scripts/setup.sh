#!/bin/bash

# Setup script for Virtual AI School
virtualenv venv
source venv/bin/activate
pip install -r requirements.txt
