#!/bin/bash

# Deploy script for Virtual AI School
python app.py
