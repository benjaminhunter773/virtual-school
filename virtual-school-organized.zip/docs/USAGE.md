# Usage Guide

1. Run `app.py` to start the server.
2. Open the browser and go to `http://localhost:5000`.
