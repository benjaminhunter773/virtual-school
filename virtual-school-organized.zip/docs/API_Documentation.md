# API Documentation

## Endpoints
- `/login`: Handles user authentication.
- `/dashboard`: Provides the main user interface.
