# Installation Guide

1. Clone the repository.
2. Set up a virtual environment.
3. Install dependencies from `requirements.txt`.
