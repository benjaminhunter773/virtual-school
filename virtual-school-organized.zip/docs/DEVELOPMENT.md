# Developer Guide

- Use `config.py` for setting configurations.
- Follow the file structure for adding new modules.
